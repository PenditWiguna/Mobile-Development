package com.dicoding.appgithub.data

data class FavItem(
    val IdFav: Int,
    val Nama: String,
    val Foto: String
)
